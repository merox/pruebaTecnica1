﻿namespace PruebaTecnica1.Models.DTO
{
    public class ClientesDTO
    {
        public int Id { get; set; } 
        public string Nombre { get; set; }
    }
}
